ACCESS PPT:[View ](MedSahayog.pdf)



MedSahayog - Your Health Companion

🌐 Live Demo

Visit the website: [MedSahayog](https://fanciful-mochi-80bc03.netlify.app/)

📌 Overview

MedSahayog is a web platform designed to provide users with comprehensive information about medicines, diseases, natural remedies, and wellness practices. It aims to assist users in making informed healthcare decisions by offering reliable and accessible health information.

🏗 Features

🔍 Medicine Information: Get detailed insights on medicine usage, dosage, side effects, and precautions.

🏥 Disease & Symptom Guide: Explore symptoms, causes, and treatments for various diseases.

🌿 Ayurveda & Natural Remedies: Discover home-based treatments and wellness therapies.

🚀 Smart Symptom Checker: A tool to help users identify possible health conditions based on symptoms.

🤖 MedBot: An interactive chatbot for quick health-related queries.

📚 Knowledge Centre: A dedicated space for healthcare-related articles and insights.

🏆 User-Friendly Interface: A clean, responsive, and intuitive UI for easy navigation.

🛠️ Tech Stack

HTML ,CSS ,Bootstrap, JAVASCRIPT
FLASK ,SQLite, HUGGING FACE

Deployment: Netlify



📌 Future Enhancements
1)AR/VR Integration – Enable immersive wellness sessions and virtual health consultations.
2)Blockchain for Health Data Security – Ensure secure and transparent user data management.
3)Wearable Device Sync – Connect with smartwatches for real-time health tracking.
4)Gamification & Rewards – Motivate users with health challenges and incentives.

Made by TEAM: BINARY TRAILS FOR MSC HACKITUP 
